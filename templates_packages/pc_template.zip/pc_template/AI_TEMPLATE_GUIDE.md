# AI Template Guide

这份文档是给后续 AI 生成代码时使用的项目说明。请严格遵守这里的约束，避免把模板改成需要构建、需要安装依赖或只能在开发环境运行的项目。

## 项目定位

这是一个 PC 端静态单页应用模板。

项目特点：

- 使用 Vue 3
- 使用 Ant Design Vue
- 支持 ECharts
- 支持 Three.js
- 使用 hash 路由
- 不使用构建工具
- 不安装 `node_modules`
- 不运行 `npm install`
- 不运行 `npm run build`
- 直接由 Nginx 或任意静态服务器托管运行



访问方式：

```text
http://localhost:8080/pc_template/#/
http://localhost:8080/pc_template/#/example
```

这里使用 hash 路由，`#` 后面的路径不会发送给服务器，所以刷新页面不容易出现 404。

## 目录结构

```text
  index.html
  src/
    main.js
    router.js
    layout.js
    pages/
      IndexPage.js
    styles/
      global.css
  assets/
    images/
    videos/
  vendor/
    vue.global.prod.js
    antd.min.js
    echarts.min.js
    dayjs.min.js
    dayjs-plugin-*.js
    three.module.js
    three.core.js
```

## 入口说明

`index.html` 负责加载本地依赖和应用入口。

已经全局引入：

- `Vue`
- `antd`
- `echarts`

`src/main.js` 负责创建 Vue 应用、读取当前路由并渲染页面。

`src/router.js` 负责维护页面路由。

`src/layout.js` 是最小布局容器。默认只包一层内容区域，不要擅自改成后台管理侧边栏布局，除非用户明确要求。

`src/pages/` 存放页面组件。

`src/styles/global.css` 存放全局样式。

`assets/images/` 存放项目图片资源，包括 AI 生成的图片、产品图、背景图、图标位图等。

`assets/videos/` 存放项目视频资源，包括 AI 生成的视频、演示视频、背景视频等。

后续 AI 为本项目生成图片或视频时，必须把生成结果保存到对应的 `assets/images/` 或 `assets/videos/` 目录下，不要散落在根目录、`src/` 或页面目录中。页面引用资源时使用项目内相对路径，例如：

```html
<img src="./assets/images/example.png" alt="">
<video src="./assets/videos/example.mp4" controls></video>
```

## 编码规则

必须遵守：

- 使用普通 `.js` 文件
- 使用浏览器原生 ES Module
- 多页面或页面资源较重时，优先使用浏览器原生 `import()` 动态加载页面 JS
- 页面组件使用 Vue Options API 对象写法
- 不使用 `.vue` 单文件组件
- 不新增 Vite、Webpack、Rollup 等构建工具
- 不新增 `package.json`
- 不新增 `node_modules`
- 不从 CDN 加载新依赖
- 新依赖如果必须使用，应该下载到 `vendor/` 并使用本地路径
- 保持代码简单，方便非开发者继续让 AI 修改

## 新增页面

新增页面时，在 `src/pages/` 下创建一个页面文件。

示例：`src/pages/AboutPage.js`

```js
export const AboutPage = {
  template: `
    <div class="page">
      <p>这是关于页面。</p>
    </div>
  `,
}
```

然后修改 `src/router.js`：

```js
import { IndexPage } from './pages/IndexPage.js'
import { AboutPage } from './pages/AboutPage.js'

export const routes = [
  {
    path: '/',
    title: '首页',
    component: IndexPage,
  },
  {
    path: '/about',
    title: '关于',
    component: AboutPage,
  },
]
```

访问：

```text
http://localhost:8080/pc_template/#/about
```

如果页面数量较多，或某些页面包含 ECharts、Three.js、编辑器、地图等较重资源，路由应优先使用动态导入，让浏览器只在访问对应页面时加载该页面 JS。不要为了动态加载引入构建工具，直接使用原生 ES Module 的 `import()`。

示例：

```js
import { IndexPage } from './pages/IndexPage.js'

export const routes = [
  {
    path: '/',
    title: '首页',
    component: IndexPage,
  },
  {
    path: '/about',
    title: '关于',
    loader: () => import('./pages/AboutPage.js').then((module) => module.AboutPage),
  },
]
```

实现动态页面加载时，需要在渲染逻辑中处理：

- 首次进入页面时执行 `route.loader()`
- 加载完成后把组件保存到当前路由或缓存对象中，避免重复请求
- 加载期间显示简单的 loading 状态
- 加载失败时显示错误状态
- 保持首页或首屏关键页面可静态引入，避免首屏额外等待

页面内的重资源也可以按交互动态加载。例如只有打开图表区域时，才执行 `import()` 加载图表相关模块。

## 使用 Ant Design Vue

Ant Design Vue 已经通过 `index.html` 加载，应用已经在 `src/main.js` 中执行：

```js
createApp(...).use(antd).mount('#app')
```

所以页面里可以直接使用 Ant Design Vue 组件。

示例：

```js
export const DemoPage = {
  template: `
    <div class="page">
      <a-button type="primary">按钮</a-button>
    </div>
  `,
}
```

## 使用 ECharts

ECharts 已经通过 `index.html` 加载，提供全局变量 `echarts`。

页面示例：

```js
export const ChartPage = {
  mounted() {
    const chart = echarts.init(this.$refs.chart)

    chart.setOption({
      xAxis: { type: 'category', data: ['A', 'B', 'C'] },
      yAxis: { type: 'value' },
      series: [{ type: 'bar', data: [12, 20, 15] }],
    })

    this.chart = chart
    window.addEventListener('resize', this.resizeChart)
  },
  beforeUnmount() {
    window.removeEventListener('resize', this.resizeChart)

    if (this.chart) {
      this.chart.dispose()
    }
  },
  methods: {
    resizeChart() {
      if (this.chart) {
        this.chart.resize()
      }
    },
  },
  template: `
    <div class="page">
      <div ref="chart" style="width: 100%; height: 320px;"></div>
    </div>
  `,
}
```

## 使用 Three.js

Three.js 使用 ES Module 方式，不在 `index.html` 里注册全局变量。

在需要 Three.js 的页面文件顶部引入：

```js
import * as THREE from '/pc_template/vendor/three.module.js'
```

页面示例：

```js
import * as THREE from '/pc_template/vendor/three.module.js'

export const ThreePage = {
  mounted() {
    const container = this.$refs.scene
    const width = container.clientWidth
    const height = container.clientHeight

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000)
    const renderer = new THREE.WebGLRenderer({ antialias: true })

    renderer.setSize(width, height)
    container.appendChild(renderer.domElement)

    const geometry = new THREE.BoxGeometry(1, 1, 1)
    const material = new THREE.MeshBasicMaterial({ color: 0x1677ff })
    const cube = new THREE.Mesh(geometry, material)

    scene.add(cube)
    camera.position.z = 3

    const animate = () => {
      this.animationFrame = requestAnimationFrame(animate)
      cube.rotation.x += 0.01
      cube.rotation.y += 0.01
      renderer.render(scene, camera)
    }

    animate()

    this.renderer = renderer
  },
  beforeUnmount() {
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame)
    }

    if (this.renderer) {
      this.renderer.dispose()
    }
  },
  template: `
    <div class="page">
      <div ref="scene" style="width: 100%; height: 360px;"></div>
    </div>
  `,
}
```

## 样式建议

全局样式写在 `src/styles/global.css`。

页面内如果只是少量样式，可以使用类名并补到全局样式文件中。

不要把模板默认做成后台管理系统样式。这个模板用于多种 PC 页面，默认应保持中性、简单。

## 修改前检查

生成代码前先确认：

- 是否需要新增页面
- 是否需要新增路由
- 是否需要新增全局样式
- 是否用到了本地已有依赖
- 是否保持静态部署能力

生成代码后检查：

- `index.html` 引用路径是否仍以 `/pc_template/vendor/`、`/pc_template/src/` 开头
- 新增页面是否已在 `src/router.js` 注册
- 没有引入 `npm`、`node_modules`、构建工具
- 没有新增远程 CDN 链接
