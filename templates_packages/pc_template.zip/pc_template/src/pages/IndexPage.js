export const IndexPage = {
  template: `
    <div class="page">
      <p style="height: 100vh; width: 100vw; text-align: center; padding-top: 40vh">我是模版示例，请替换我进行开发吧</p>
    </div>
  `,
}
