import { AppLayout } from './layout.js'
import { getCurrentRoute, routes } from './router.js'

const { createApp } = Vue

createApp({
  components: {
    AppLayout,
  },
  data() {
    return {
      currentRoute: getCurrentRoute(),
      routes,
    }
  },
  computed: {
    currentPage() {
      return this.currentRoute.component
    },
  },
  mounted() {
    window.addEventListener('hashchange', this.syncRoute)
  },
  beforeUnmount() {
    window.removeEventListener('hashchange', this.syncRoute)
  },
  methods: {
    syncRoute() {
      this.currentRoute = getCurrentRoute()
    },
  },
  template: `
    <a-config-provider :theme="{ token: { borderRadius: 8, colorPrimary: '#1677ff' } }">
      <app-layout :routes="routes" :current-route="currentRoute">
        <component :is="currentPage"></component>
      </app-layout>
    </a-config-provider>
  `,
}).use(antd).mount('#app')
