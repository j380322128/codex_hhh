import { AppLayout } from './layout.js'
import { getCurrentRoute, routes } from './router.js'

const { createApp } = Vue

createApp({
  components: {
    AppLayout,
  },
  data() {
    return {
      currentRoute: getCurrentRoute(),
      routes,
    }
  },
  computed: {
    currentPage() {
      return this.currentRoute.component
    },
  },
  mounted() {
    window.addEventListener('hashchange', this.syncRoute)
  },
  beforeUnmount() {
    window.removeEventListener('hashchange', this.syncRoute)
  },
  methods: {
    syncRoute() {
      this.currentRoute = getCurrentRoute()
    },
  },
  template: `
    <van-config-provider :theme-vars="{ primaryColor: '#1677ff', borderRadiusMd: '8px' }">
      <app-layout :routes="routes" :current-route="currentRoute">
        <component :is="currentPage"></component>
      </app-layout>
    </van-config-provider>
  `,
}).use(vant).mount('#app')
