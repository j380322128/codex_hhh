export const AppLayout = {
  props: {
    routes: {
      type: Array,
      required: true,
    },
    currentRoute: {
      type: Object,
      required: true,
    },
  },
  computed: {
    selectedKeys() {
      return [this.currentRoute.path]
    },
  },
  methods: {
    goToRoute(path) {
      window.location.hash = path
    },
  },
  template: `
    <main class="app-content">
        <slot></slot>
    </main>
  `,
}
