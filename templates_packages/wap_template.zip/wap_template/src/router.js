import { IndexPage } from './pages/IndexPage.js'

export const routes = [
  {
    path: '/',
    title: '首页',
    component: IndexPage,
  }
]

const NotFoundPage = {
  template: `
    <div class="page">
      <p>页面不存在。</p>
    </div>
  `,
}

export function getCurrentPath() {
  const hashPath = window.location.hash.replace(/^#/, '')
  return normalizePath(hashPath || '/')
}

export function getCurrentRoute() {
  const path = getCurrentPath()
  const matchedRoute = routes.find((route) => route.path === path)

  return (
    matchedRoute || {
      path,
      title: '页面不存在',
      component: NotFoundPage,
    }
  )
}

function normalizePath(path) {
  if (!path.startsWith('/')) {
    return `/${path}`
  }

  return path
}
