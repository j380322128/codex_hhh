export const IndexPage = {
  data() {
    return {
      refreshing: false,
    }
  },
  methods: {
    handleRefresh() {
      window.setTimeout(() => {
        this.refreshing = false
        vant.showToast('已刷新')
      }, 500)
    },
  },
  template: `
    <van-pull-refresh v-model="refreshing" @refresh="handleRefresh">
      <div class="page mobile-demo-page">
        <van-nav-bar title="移动端模板" fixed placeholder safe-area-inset-top />
        <section class="mobile-hero">
          <h1>我是 WAP 模板示例</h1>
          <p>请替换这里的内容进行移动端页面开发。</p>
        </section>
      </div>
    </van-pull-refresh>
  `,
}
