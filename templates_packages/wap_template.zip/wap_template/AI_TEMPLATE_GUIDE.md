# AI Template Guide

这份文档是给后续 AI 生成代码时使用的项目说明。请严格遵守这里的约束，避免把模板改成需要构建、需要安装依赖或只能在开发环境运行的项目。

## 项目定位

这是一个 WAP / H5 移动端静态单页应用模板。

项目特点：

- 使用 Vue 3
- 使用 Vant 4
- 支持 ECharts
- 支持 Three.js
- 使用 hash 路由
- 使用 rem 做移动端尺寸适配
- 支持 iOS / Android 安全区
- 不使用构建工具
- 不安装 `node_modules`
- 不运行 `npm install`
- 不运行 `npm run build`
- 直接由 Nginx 或任意静态服务器托管运行

访问方式：

```text
http://localhost:8080/wap_template/#/
http://localhost:8080/wap_template/#/example
```

这里使用 hash 路由，`#` 后面的路径不会发送给服务器，所以刷新页面不容易出现 404。

## 目录结构

```text
  index.html
  src/
    main.js
    router.js
    layout.js
    pages/
      IndexPage.js
    styles/
      global.css
  assets/
    images/
    videos/
  vendor/
    vue.global.prod.js
    vant.min.js
    vant.css
    echarts.min.js
    dayjs.min.js
    dayjs-plugin-*.js
    three.module.js
    three.core.js
    reset.css
```

## 入口说明

`index.html` 负责加载本地依赖和应用入口。

已经全局引入：

- `Vue`
- `vant`
- `echarts`
- `dayjs`

`src/main.js` 负责创建 Vue 应用、读取当前路由并渲染页面。

`src/router.js` 负责维护页面路由。

`src/layout.js` 是最小布局容器。默认只包一层内容区域，不要擅自改成 PC 后台管理侧边栏布局。

`src/pages/` 存放页面组件。

`src/styles/global.css` 存放全局样式和移动端适配规则。

`assets/images/` 存放项目图片资源，包括 AI 生成的图片、产品图、背景图、图标位图等。

`assets/videos/` 存放项目视频资源，包括 AI 生成的视频、演示视频、背景视频等。

后续 AI 为本项目生成图片或视频时，必须把生成结果保存到对应的 `assets/images/` 或 `assets/videos/` 目录下，不要散落在根目录、`src/` 或页面目录中。页面引用资源时使用项目内相对路径，例如：

```html
<img src="./assets/images/example.png" alt="">
<video src="./assets/videos/example.mp4" controls></video>
```

## 编码规则

必须遵守：

- 使用普通 `.js` 文件
- 使用浏览器原生 ES Module
- 多页面或页面资源较重时，优先使用浏览器原生 `import()` 动态加载页面 JS
- 页面组件使用 Vue Options API 对象写法
- 不使用 `.vue` 单文件组件
- 不新增 Vite、Webpack、Rollup 等构建工具
- 不新增 `package.json`
- 不新增 `node_modules`
- 不从 CDN 加载新依赖
- 新依赖如果必须使用，应该下载到 `vendor/` 并使用本地路径
- 保持代码简单，方便非开发者继续让 AI 修改

## 移动端适配

模板使用 rem 作为主要尺寸单位。`src/styles/global.css` 中已经设置：

```css
html {
  font-size: calc(100vw / 3.75);
}

@media (min-width: 480px) {
  html {
    font-size: 128px;
  }
}
```

含义：

- 以 375px 设计稿为默认基准
- `1rem = 100px`，所以 `0.16rem` 等于设计稿里的 16px
- 480px 以上限制最大字号，避免桌面浏览器预览时无限放大
- `.app-content` 最大宽度为 480px，页面在大屏上居中展示

写移动端样式时：

- 尺寸、间距、圆角、字号优先用 `rem`
- 1px 边框、阴影、极细线可以继续用 `px`
- 不要写固定 PC 宽度，例如 `1200px`、`1300px`
- 不要使用横向大表格作为主要信息结构
- 不要依赖 hover 交互，移动端应以点击、滑动、吸底按钮、弹层为主
- 按钮、输入框、列表项应有足够触控面积，常用点击区域建议不小于 44px
- 首屏要考虑 iPhone 刘海屏和底部 Home Indicator

安全区变量已经定义：

```css
:root {
  --app-safe-top: env(safe-area-inset-top, 0px);
  --app-safe-right: env(safe-area-inset-right, 0px);
  --app-safe-bottom: env(safe-area-inset-bottom, 0px);
  --app-safe-left: env(safe-area-inset-left, 0px);
}
```

底部固定操作区示例：

```css
.bottom-bar {
  position: fixed;
  right: 0;
  bottom: 0;
  left: 0;
  max-width: var(--app-max-width);
  margin: 0 auto;
  padding: 0.12rem 0.16rem calc(0.12rem + var(--app-safe-bottom));
  background: #fff;
}
```

## 移动端体验规则

生成页面时优先使用移动端常见结构：

- `van-nav-bar`：顶部导航
- `van-tabbar`：底部主导航
- `van-tabs`：同级内容切换
- `van-cell` / `van-cell-group`：信息项、设置项、列表入口
- `van-list`：长列表加载
- `van-pull-refresh`：下拉刷新
- `van-popup` / `van-action-sheet`：移动端弹层和操作菜单
- `van-submit-bar` / 自定义吸底栏：关键提交操作
- `van-search`：搜索入口
- `van-form` / `van-field`：表单
- `van-swipe`：轮播

不要把 PC 的后台布局、顶部菜单、侧边栏、宽表格直接照搬到移动端。移动端页面应优先做成单列内容流、卡片列表、分组单元格、吸底操作和弹层筛选。

## 新增页面

新增页面时，在 `src/pages/` 下创建一个页面文件。

示例：`src/pages/AboutPage.js`

```js
export const AboutPage = {
  template: `
    <div class="page">
      <van-nav-bar title="关于" fixed placeholder safe-area-inset-top />
      <van-cell-group inset>
        <van-cell title="版本" value="1.0.0" />
      </van-cell-group>
    </div>
  `,
}
```

然后修改 `src/router.js`：

```js
import { IndexPage } from './pages/IndexPage.js'
import { AboutPage } from './pages/AboutPage.js'

export const routes = [
  {
    path: '/',
    title: '首页',
    component: IndexPage,
  },
  {
    path: '/about',
    title: '关于',
    component: AboutPage,
  },
]
```

访问：

```text
http://localhost:8080/wap_template/#/about
```

如果页面数量较多，或某些页面包含 ECharts、Three.js、编辑器、地图等较重资源，路由应优先使用动态导入，让浏览器只在访问对应页面时加载该页面 JS。不要为了动态加载引入构建工具，直接使用原生 ES Module 的 `import()`。

示例：

```js
import { IndexPage } from './pages/IndexPage.js'

export const routes = [
  {
    path: '/',
    title: '首页',
    component: IndexPage,
  },
  {
    path: '/about',
    title: '关于',
    loader: () => import('./pages/AboutPage.js').then((module) => module.AboutPage),
  },
]
```

实现动态页面加载时，需要在渲染逻辑中处理：

- 首次进入页面时执行 `route.loader()`
- 加载完成后把组件保存到当前路由或缓存对象中，避免重复请求
- 加载期间显示简单的 loading 状态
- 加载失败时显示错误状态
- 保持首页或首屏关键页面可静态引入，避免首屏额外等待

页面内的重资源也可以按交互动态加载。例如只有打开图表区域时，才执行 `import()` 加载图表相关模块。

## 使用 Vant 4

Vant 4 已经通过 `index.html` 加载，应用已经在 `src/main.js` 中执行：

```js
createApp(...).use(vant).mount('#app')
```

所以页面里可以直接使用 Vant 组件。

示例：

```js
export const DemoPage = {
  methods: {
    submit() {
      vant.showToast('提交成功')
    },
  },
  template: `
    <div class="page">
      <van-nav-bar title="示例" fixed placeholder safe-area-inset-top />
      <van-cell-group inset>
        <van-field label="姓名" placeholder="请输入姓名" />
      </van-cell-group>
      <div class="mobile-actions">
        <van-button type="primary" block round @click="submit">提交</van-button>
      </div>
    </div>
  `,
}
```

Vant 函数式能力通过全局变量 `vant` 调用，例如：

```js
vant.showToast('提示')
vant.showDialog({ message: '确认操作？' })
```

## 使用 ECharts

ECharts 已经通过 `index.html` 加载，提供全局变量 `echarts`。

移动端图表必须注意：

- 容器高度使用 `rem` 或明确的移动端高度
- 图例、坐标轴文字要少，避免拥挤
- 监听 `resize`
- 页面卸载时调用 `dispose`

页面示例：

```js
export const ChartPage = {
  mounted() {
    const chart = echarts.init(this.$refs.chart)

    chart.setOption({
      grid: { left: 28, right: 12, top: 24, bottom: 28 },
      xAxis: { type: 'category', data: ['A', 'B', 'C'] },
      yAxis: { type: 'value' },
      series: [{ type: 'bar', data: [12, 20, 15] }],
    })

    this.chart = chart
    window.addEventListener('resize', this.resizeChart)
  },
  beforeUnmount() {
    window.removeEventListener('resize', this.resizeChart)

    if (this.chart) {
      this.chart.dispose()
    }
  },
  methods: {
    resizeChart() {
      if (this.chart) {
        this.chart.resize()
      }
    },
  },
  template: `
    <div class="page">
      <van-nav-bar title="图表" fixed placeholder safe-area-inset-top />
      <div ref="chart" style="width: 100%; height: 2.8rem;"></div>
    </div>
  `,
}
```

## 使用 Three.js

Three.js 使用 ES Module 方式，不在 `index.html` 里注册全局变量。

在需要 Three.js 的页面文件顶部引入：

```js
import * as THREE from '/wap_template/vendor/three.module.js'
```

移动端 Three.js 页面必须注意：

- Canvas 容器不要小于首屏主要区域
- 根据设备像素比设置 renderer pixel ratio，但限制上限，避免移动端性能过高
- 监听窗口尺寸变化
- 离开页面时取消动画并释放 renderer

页面示例：

```js
import * as THREE from '/wap_template/vendor/three.module.js'

export const ThreePage = {
  mounted() {
    const container = this.$refs.scene
    const width = container.clientWidth
    const height = container.clientHeight

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000)
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2))
    renderer.setSize(width, height)
    container.appendChild(renderer.domElement)

    const geometry = new THREE.BoxGeometry(1, 1, 1)
    const material = new THREE.MeshBasicMaterial({ color: 0x1677ff })
    const cube = new THREE.Mesh(geometry, material)

    scene.add(cube)
    camera.position.z = 3

    const animate = () => {
      this.animationFrame = requestAnimationFrame(animate)
      cube.rotation.x += 0.01
      cube.rotation.y += 0.01
      renderer.render(scene, camera)
    }

    animate()

    this.renderer = renderer
  },
  beforeUnmount() {
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame)
    }

    if (this.renderer) {
      this.renderer.dispose()
    }
  },
  template: `
    <div class="page">
      <van-nav-bar title="3D" fixed placeholder safe-area-inset-top />
      <div ref="scene" style="width: 100%; height: 4.8rem;"></div>
    </div>
  `,
}
```

## 样式建议

全局样式写在 `src/styles/global.css`。

页面内如果只是少量样式，可以使用类名并补到全局样式文件中。

默认模板保持中性、简单。除非用户明确要求，不要把模板默认做成电商首页、后台管理、营销落地页或复杂视觉大屏。

移动端页面应优先保障：

- 单手操作可达性
- 滚动流畅
- 内容层级清楚
- 关键操作固定或容易找到
- 表单输入体验清晰
- 弹层和吸底栏不遮挡安全区

## 修改前检查

生成代码前先确认：

- 是否需要新增页面
- 是否需要新增路由
- 是否需要新增全局样式
- 是否用到了本地已有依赖
- 是否需要移动端触控、下拉刷新、吸底操作、弹层筛选等特性
- 是否保持静态部署能力

生成代码后检查：

- `index.html` 引用路径是否仍以 `/wap_template/vendor/`、`/wap_template/src/` 开头
- 新增页面是否已在 `src/router.js` 注册
- 没有引入 `npm`、`node_modules`、构建工具
- 没有新增远程 CDN 链接
- 没有继续使用 Ant Design Vue 或 `a-` 组件
- 主要移动端尺寸是否使用 `rem`
- 固定顶部或底部区域是否考虑安全区
